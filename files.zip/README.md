# FriendDrop: deploy for free

Stack: Node.js + Express on Render (free web service) + Neon (free Postgres).
Render's own free Postgres expires after 30 days, so use Neon for the database.

## 1. Database (Neon)
1. Sign up at neon.com and create a project.
2. Copy the connection string (starts with postgresql://).

## 2. Code (GitHub)
1. Create a new GitHub repository.
2. Upload every file in this folder (server.js, package.json, render.yaml, public/, .gitignore).

## 3. Website (Render)
1. Sign up at render.com and connect your GitHub account.
2. New > Blueprint, pick your repository (it reads render.yaml). Plan: Free.
3. When asked for DATABASE_URL, paste the Neon connection string.
4. Deploy. Your site will be at https://<name>.onrender.com.

## Things to know
- The free web service sleeps after 15 minutes without visitors; the next visit takes about a minute to wake it.
- Neon's free plan has 0.5 GB of storage. Files are stored in the database (10 MB max each, change with MAX_UPLOAD_MB), so heavy video use will fill it.
- Passwords are hashed on the server (scrypt). Direct messages are only readable by the two people in them.
- Anyone logged in who has a file's link can open it (links are random and unguessable).
- Optional: add a custom domain in Render's settings for your site.
