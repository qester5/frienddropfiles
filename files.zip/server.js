const express=require('express'),{Pool}=require('pg'),crypto=require('crypto'),path=require('path');
const app=express(),PORT=process.env.PORT||3000,SECRET=process.env.SESSION_SECRET||'dev-secret-change-me';
const MAXB=(+process.env.MAX_UPLOAD_MB||10)*1048576;
const url=process.env.DATABASE_URL||'postgres://localhost/frienddrop';
const pool=new Pool({connectionString:url,ssl:/localhost|127\.0\.0\.1/.test(url)?false:{rejectUnauthorized:false}});
pool.on('error',e=>console.error('pg idle error',e.message));
app.set('trust proxy',1);
let ver=crypto.randomUUID();const bump=()=>{ver=crypto.randomUUID()};

// ---- auth: scrypt passwords, signed cookie ----
const sign=s=>crypto.createHmac('sha256',SECRET).update(s).digest('hex');
const hashPw=(pw,salt=crypto.randomBytes(16).toString('hex'))=>new Promise((ok,no)=>crypto.scrypt(pw,salt,32,(e,d)=>e?no(e):ok(salt+':'+d.toString('hex'))));
const checkPw=async(pw,st)=>{const h=await hashPw(pw,st.split(':')[0]);return h.length===st.length&&crypto.timingSafeEqual(Buffer.from(h),Buffer.from(st))};
const who=q=>{const c=(q.headers.cookie||'').split(/;\s*/).find(x=>x.startsWith('fd='));if(!c)return null;
  const[u,e,g]=decodeURIComponent(c.slice(3)).split('|');
  return g&&g.length===64&&+e>Date.now()&&crypto.timingSafeEqual(Buffer.from(g),Buffer.from(sign(u+'|'+e)))?u:null};
const login=(q,r,u)=>{const e=Date.now()+30*864e5;r.setHeader('Set-Cookie','fd='+encodeURIComponent(u+'|'+e+'|'+sign(u+'|'+e))+'; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000'+(q.secure?'; Secure':''))};
const tries={};const limited=(k,n=10)=>{const t=Date.now(),a=(tries[k]=(tries[k]||[]).filter(x=>t-x<6e5));a.push(t);return a.length>n};
const auth=(q,r,n)=>{q.u=who(q);q.u?n():r.status(401).json({error:'auth'})};

app.use(express.json({limit:'100kb'}));
app.post('/api/signup',async(q,r)=>{
  const{name='',pw=''}=q.body||{},k=String(name).trim().toLowerCase();
  if(limited('s'+q.ip))return r.json({error:'Too many attempts. Try again in a few minutes.'});
  if(!/^[a-z0-9_.-]{2,24}$/.test(k))return r.json({error:'Name: 2–24 letters, numbers, _ . -'});
  if(String(pw).length<6)return r.json({error:'Password needs at least 6 characters'});
  const ins=await pool.query('insert into accounts(k,pw,created) values($1,$2,$3) on conflict do nothing',[k,await hashPw(String(pw)),Date.now()]);
  if(!ins.rowCount)return r.json({error:'That name is taken'});
  await pool.query("insert into docs values('users',$1,$2)",[k,{name:String(name).trim()}]);
  bump();login(q,r,k);r.json({user:k});
});
app.post('/api/login',async(q,r)=>{
  const{name='',pw=''}=q.body||{},k=String(name).trim().toLowerCase();
  if(limited('l'+q.ip,20))return r.json({error:'Too many attempts. Try again in a few minutes.'});
  const a=(await pool.query('select pw from accounts where k=$1',[k])).rows[0];
  if(!a||!(await checkPw(String(pw),a.pw)))return r.json({error:'Wrong name or password'});
  login(q,r,k);r.json({user:k});
});
app.post('/api/logout',(q,r)=>{r.setHeader('Set-Cookie','fd=; Max-Age=0; Path=/');r.json({})});
app.get('/api/me',(q,r)=>r.json({user:who(q)}));
app.get('/api/v',(q,r)=>r.json({v:ver}));

// ---- documents with per-collection rules ----
const COL=['users','uploads','follows','likes','comments','messages'];
const canRead=(c,d,u)=>c==='uploads'?d.pub===true||d.owner===u:c==='messages'?d.from===u||d.to===u:true;
const canWrite=(c,id,d,old,u)=>{switch(c){
  case'users':return id===u&&!!d;
  case'uploads':return(!old||old.owner===u)&&(!d||d.owner===u);
  case'follows':return id.startsWith(u+'~')&&(!d||(d.from===u&&id===d.from+'~'+d.to));
  case'likes':return id.endsWith('~'+u)&&(!d||d.by===u);
  case'comments':return(!old||old.by===u)&&(!d||d.by===u);
  case'messages':return!old&&!!d&&d.from===u;
}return false};
const okId=(c,id)=>COL.includes(c)&&/^[\w.~:@+-]{1,120}$/.test(id);
const getDoc=async(c,id)=>(await pool.query('select data from docs where col=$1 and id=$2',[c,id])).rows[0];
app.get('/api/c/:col',auth,async(q,r)=>{const c=q.params.col;if(!COL.includes(c))return r.status(404).end();
  r.json((await pool.query('select id,data from docs where col=$1',[c])).rows.filter(x=>canRead(c,x.data,q.u)))});
app.get('/api/d/:col/:id',auth,async(q,r)=>{const{col:c,id}=q.params;if(!okId(c,id))return r.status(404).end();
  const x=await getDoc(c,id);x&&canRead(c,x.data,q.u)?r.json(x.data):r.status(404).end()});
app.put('/api/d/:col/:id',auth,async(q,r)=>{const{col:c,id}=q.params,d=q.body;
  if(!okId(c,id)||!d||typeof d!=='object'||Array.isArray(d)||JSON.stringify(d).length>20000)return r.status(400).json({error:'bad'});
  const old=await getDoc(c,id);if(!canWrite(c,id,d,old&&old.data,q.u))return r.status(403).json({error:'forbidden'});
  await pool.query('insert into docs values($1,$2,$3) on conflict(col,id) do update set data=$3',[c,id,d]);bump();r.json({ok:1})});
app.delete('/api/d/:col/:id',auth,async(q,r)=>{const{col:c,id}=q.params;if(!okId(c,id))return r.status(400).end();
  const old=await getDoc(c,id);if(!canWrite(c,id,null,old&&old.data,q.u))return r.status(403).json({error:'forbidden'});
  await pool.query('delete from docs where col=$1 and id=$2',[c,id]);bump();r.json({ok:1})});

// ---- files (stored in Postgres) ----
const TYPES=['image/png','image/jpeg','image/gif','image/webp','video/mp4','video/webm','audio/mpeg','audio/wav','audio/ogg','audio/mp4','audio/webm','audio/aac','application/pdf','text/plain','text/csv','text/markdown','application/json'];
app.post('/api/upload',auth,express.raw({type:()=>true,limit:MAXB}),async(q,r)=>{
  const type=(q.headers['content-type']||'').split(';')[0].trim();
  if(!TYPES.includes(type)||!Buffer.isBuffer(q.body)||!q.body.length)return r.status(415).json({error:'unsupported_type'});
  const id=crypto.randomUUID();
  await pool.query('insert into blobs values($1,$2,$3,$4,$5)',[id,type,q.body.length,q.u,q.body]);
  r.json({id,contentType:type,sizeBytes:q.body.length});
});
app.delete('/api/blob/:id',auth,async(q,r)=>{await pool.query('delete from blobs where id=$1 and owner=$2',[q.params.id,q.u]);r.json({ok:1})});
app.get('/_blob/:id',auth,async(q,r)=>{
  const b=(await pool.query('select type,size,data from blobs where id=$1',[q.params.id])).rows[0];if(!b)return r.status(404).end();
  r.set({'Content-Type':b.type,'X-Content-Type-Options':'nosniff','Accept-Ranges':'bytes','Cache-Control':'private, max-age=3600'});
  const m=/bytes=(\d*)-(\d*)/.exec(q.headers.range||'');
  if(m){const s=m[1]?+m[1]:0,e=m[2]?Math.min(+m[2],b.size-1):b.size-1;if(s>e||s>=b.size)return r.status(416).end();
    r.status(206).set({'Content-Range':`bytes ${s}-${e}/${b.size}`,'Content-Length':e-s+1}).end(b.data.subarray(s,e+1))}
  else r.set('Content-Length',b.size).end(b.data);
});

app.use(express.static(path.join(__dirname,'public')));
app.use((e,q,r,n)=>{console.error(e.message);r.status(e.status||500).json({error:e.status===413?'too_large':'server'})});
process.on('unhandledRejection',e=>console.error('unhandled',e&&e.message));

pool.query(`create table if not exists accounts(k text primary key,pw text not null,created bigint);
create table if not exists docs(col text,id text,data jsonb not null,primary key(col,id));
create table if not exists blobs(id text primary key,type text,size int,owner text,data bytea)`)
  .then(()=>app.listen(PORT,()=>console.log('FriendDrop on '+PORT)))
  .catch(e=>{console.error('Database error:',e.message);process.exit(1)});
